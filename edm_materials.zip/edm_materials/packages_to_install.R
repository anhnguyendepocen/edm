
# Packages to be used
packages <- c("data.table", "tidyverse","e1071", "caret", "mlr",
              "modelr", "randomForest", "rpart", "rpart.plot", 
              "GGally", "ggExtra")

install.packages(packages)